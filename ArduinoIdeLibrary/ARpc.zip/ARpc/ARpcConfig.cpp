#include "ARpcConfig.h"

const char *argDelim="|";
const char *msgDelim="\n";
const char *okMsg="ok";
const char *errMsg="err";
const char *infoMsg="info";
const char *measurementMsg="meas";
const char *measurementBMsg="measb";
const char *syncMsg="sync";
const char *synccMsg="syncc";
const char *syncrMsg="syncr";
const char *stateChangedMsg="statechanged";
const char *bCastMsg="#broadcast";
