#include "ARpcConfig.h"

const char *argDelim="|";
const char *msgDelim="\n";
const char *okMsg="ok";
const char *errMsg="err";
const char *infoMsg="info";
const char *measurementMsg="meas";
const char *measurementFMsg="measf";
const char *syncMsg="sync";
const char *stateChangedMsg="statechanged";
const char *bCastMsg="#broadcast";
