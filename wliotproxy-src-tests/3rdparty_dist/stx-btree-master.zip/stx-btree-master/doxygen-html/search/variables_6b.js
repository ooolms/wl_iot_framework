var searchData=
[
  ['key_5fcomp',['key_comp',['../a00022.html#a7fa676ec0e6b36fde48f49358de96c74',1,'stx::btree::value_compare']]],
  ['key_5ftype_5fsize',['key_type_size',['../a00012.html#a8f67df3531d38ffcef8ad82d9da065f3',1,'stx::btree::dump_header']]]
];
