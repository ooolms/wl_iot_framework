var searchData=
[
  ['nextleaf',['nextleaf',['../a00017.html#a32f06cf3a6f67709039ca40851b03367',1,'stx::btree::leaf_node']]],
  ['node',['node',['../a00018.html',1,'stx::btree']]],
  ['nodes',['nodes',['../a00021.html#adf69b8f2b4df771fc5b1bd4e248a7a47',1,'stx::btree::tree_stats']]]
];
