var searchData=
[
  ['version',['version',['../a00012.html#a71d827c1ccd04d8e6233ff219912c595',1,'stx::btree::dump_header']]]
];
