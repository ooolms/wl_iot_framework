var searchData=
[
  ['stx',['stx',['../a00036.html',1,'']]]
];
